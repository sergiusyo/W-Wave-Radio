import GraphModal from './graph-modal';
import 'element-closest-polyfill';
import './graph-modal.css';
global.GraphModal = GraphModal;